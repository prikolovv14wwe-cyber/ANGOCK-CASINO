/**
 * ANGOCK ↔ Jenny Drop. Игра считает раунд сама (барабан, RTP 96%),
 * а деньги идут через сервер: спин списывается там, выигрыш начисляется там
 * (не больше потолка). Локальный баланс игры — просто отображение серверного.
 */
(function () {
  if (!window.AG || !AG.on) return;
  let rm = null;          // менеджер раунда игры
  let lastIdle = null;    // баланс до начала раунда (для подсчёта полной цены спина с покупкой бонуса)
  let serverBalance = null;

  const sync = (b) => {
    serverBalance = b;
    if (!rm || rm.isRoundActive) return;
    A.syncing = true;
    try { rm.setBalance(b); } finally { A.syncing = false; }
    lastIdle = rm.balance;
  };

  const A = (window.__ANGOCK = {
    syncing: false,
    attach(m) {
      rm = m;
      A.rm = m;
      if (serverBalance != null) sync(serverBalance);
      AG.balance().then(sync).catch((e) => AG.err(e));
    },
    spent(m) {
      const stake = Math.round((lastIdle ?? m.balance + m.spinCost) - m.balance);
      AG.begin(m.currentBet, stake).catch((e) => AG.err(e));
    },
    finished(m) {
      const win = m.roundReward;
      lastIdle = m.balance;
      AG.win(win).then(sync).catch(() => {});
    },
  });
})();
